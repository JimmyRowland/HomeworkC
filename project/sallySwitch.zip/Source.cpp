/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 10/15
o Purpose: switch
o Input:
o Output:
Dodgers
Dodgers
Rams Lakers
Rams Lakers
Lakers
Lakers
Los Angeles Dodgers
Los Angeles Dodgers


*/
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
void MySwitch(int value) {
	if (value == 0) {
		cout << "Los Angeles ";
		cout << "Dodgers ";
	}
	else if (value == 2) {
		cout << "Dodgers ";
	}
	else if (value == 1 || value == 5) {
		cout << "Rams ";
		cout << "Lakers ";
	}
	else if (value == 14 || value == 15) {
		cout << "Lakers ";
	}
	else {
		cout << "Clippers";
	}
	cout << endl;
}
void SallySwitch(int value) {
	switch (value)
	{
	case 0:
		cout << "Los Angeles ";
	case 2:
		cout << "Dodgers ";
		break;
	case 1:
	case 5:
		cout << "Rams ";
	case 14:
	case 15:
		cout << "Lakers ";
		break;
	default:
		cout << "Clippers";
			break;
	}
	cout << endl;
}

int main() {

	SallySwitch(2);
	MySwitch(2);
	SallySwitch(1);
	MySwitch(1);
	SallySwitch(15);
	MySwitch(15);
	SallySwitch(0);
	MySwitch(0);
	int x;
	cin >> x;
	return 0;

}