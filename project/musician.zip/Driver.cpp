/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 12/4
o Project 2: Musician
o Input: 
o Output:
ptrM->getInstrument()
guitar
ptrM->play()
musician playing her guitar
ptrP->getInstrument()
piano
ptrP->play()
pianist playing the piano
temp pointing at a musician...
temp->play()
musician playing her guitar
temp pointing at a pianist...
temp->play()
pianist playing the piano



*/
#include "Musician.h"
#include "PianoPlayer.h"
#include <iostream>
#include <string>
using namespace std;


int main() {

	Musician * ptrM = new Musician("guitar");
	cout << "ptrM->getInstrument()" << endl;
	cout << ptrM->getInstrument() << endl;  // guitar
	cout << "ptrM->play()" << endl;
	ptrM->play();
	PianoPlayer * ptrP = new PianoPlayer();
	cout << "ptrP->getInstrument()" << endl;
	cout << ptrP->getInstrument() << endl; // piano
	cout << "ptrP->play()" << endl;
	ptrP->play();


	Musician m;
	PianoPlayer p;
	m = p;      /// legal
				/// p = m;  /// illegal!

	Musician * temp;
	cout << "temp pointing at a musician..." << endl;
	temp = ptrM;
	cout << "temp->play()" << endl;
	temp->play();
	cout << "temp pointing at a pianist..." << endl;
	temp = ptrP;
	cout << "temp->play()" << endl;
	temp->play();
	
	int x;
	cin >> x;

	return(0);
}