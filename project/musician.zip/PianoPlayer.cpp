#include "Musician.h"
#include "PianoPlayer.h"
#include <iostream>
#include <stdexcept>
#include <string>
PianoPlayer::PianoPlayer(string instument) : Musician(instument){
	
}
void PianoPlayer::play() {
	cout << "pianist playing the " << getInstrument() << endl;
}