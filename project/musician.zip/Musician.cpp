#include "Musician.h"
#include <iostream>
#include <stdexcept>
#include <string>

Musician::Musician(string instuments) : instrument(instuments){
	
}

string Musician::getInstrument() const {
	return instrument;
}
void Musician::play() {
	cout << "musician playing her " << getInstrument() << endl;
}
