#ifndef PIANOPLAYER_H
#define PIANOPLAYER_H
#include "Musician.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
class PianoPlayer : public Musician {
public:
	PianoPlayer(string instrument = "piano");
	void play();

};
#endif