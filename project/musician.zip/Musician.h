#ifndef MUSICIAN_H
#define MUSICIAN_H
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
class Musician {
public:
	
	Musician(string instrument = "undefined");
	string getInstrument() const;
	virtual void play();
private:
	string instrument;
};


#endif