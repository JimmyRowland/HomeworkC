/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 12/10
o Class Door
o Input: 
o Output:
knob is locked!
knob is locked!
knob is locked!
knob is locked!
turning knob...
pushing knob...
turning knob...
pulling knob...




*/
#include "Door.h"
#include "DoorKnob.h"
#include <iostream>
#include <string>
using namespace std;


int main() {
	Door d;
	Door UnlockedAndOpen(false, true);
	d.open();
	d.close();
	UnlockedAndOpen.open();
	UnlockedAndOpen.close();
	int x;
	cin >> x;

	return(0);
}