#ifndef DOORKNOB_H
#define DOORKNOB_H
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
class DoorKnob {
public:
	DoorKnob();
	DoorKnob(bool isLockable,bool isLocked = false);
	void turn();
	void push();
	void pull();
	bool canBeLocked() const;
	void lock(); // only does something 
				 // if the knob is lockable
	void unlock();
private:
	bool myIsLockable;
	bool myIsLocked;
};
#endif