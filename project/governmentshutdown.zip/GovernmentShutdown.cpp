#include "GovernmentShutdown.h"
#include <iostream>
#include <stdexcept>
#include <string>
GovernmentShutdown::GovernmentShutdown(string startdate, string enddate, double cost) {
	my_StartDate = startdate;
	my_EndDate = enddate;
	my_Cost = cost;
}


void GovernmentShutdown::setStartDate(string date) {
	my_StartDate = date;
}
void GovernmentShutdown::setEndDate(string date) {
	my_EndDate = date;
}
void GovernmentShutdown::setCost(double cost) {
	my_Cost = cost;
}
string  GovernmentShutdown::getStartDate() {
	return my_StartDate;
}
string  GovernmentShutdown::getEndDate() {
	return my_EndDate;
}

double  GovernmentShutdown::getCost() {
	return(my_Cost);
}
ostream& operator <<(ostream& outs,
	const GovernmentShutdown& n) {
	n.printGovernmentShutdown(outs);
	return(outs);
}
void GovernmentShutdown::printGovernmentShutdown(std::ostream& outs) const {
	using namespace std;
	cout.precision(1);
	cout << "Start day:" + my_StartDate << " End day: " + my_EndDate << " cost:" << fixed << my_Cost << endl;
	
}

GovernmentShutdown::~GovernmentShutdown() {
	cout << "This GovernmentShutdown is destroyed\n";

}
