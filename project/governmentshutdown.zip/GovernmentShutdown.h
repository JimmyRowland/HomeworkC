#ifndef GovernmentShutdown_H
#define GovernmentShutdown_H
#include <iostream>
#include <string>
using namespace std;


class GovernmentShutdown {

private:
	string my_StartDate; // the start of the shutdown
	string my_EndDate; // the end of the shutdown
	double my_Cost; // the GDP cost of the shutdown in billions
public:
	
	GovernmentShutdown(string startdate, string enddate, double cost);



	string getStartDate(); // getter methods
	string getEndDate();
	double getCost(); // in billions!


	void setStartDate(string date); // setter methods
	void setEndDate(string date);
	void setCost(double cost);
	void printGovernmentShutdown(std::ostream& outs) const;
	friend std::ostream& operator <<(std::ostream& outs, const GovernmentShutdown& n);
	~GovernmentShutdown();



};

#endif