/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 11/20
o Project 13: Government Shutdown
o Input:
o Output:
This GovernmentShutdown is destroyed
Start day:1 End day: 11 cost:222222222222.2

Start day:2 End day: 12 cost:333333333333.3




*/
#include "GovernmentShutdown.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;


int main() {

	GovernmentShutdown tenday("1", "11", 222222222222.2);

	try {
		
		GovernmentShutdown teenday("1", "11", 222222222222.2);
	}
	catch (std::logic_error le) {
		cout << "creat GovernmentShutdown failed" << endl;
	}


	/// test should be unchanged
	

	try {
		
		
		cout << tenday << endl;
	}
	catch (std::logic_error le) {
		cout << "get failed" << endl;
	}



	try {
		
		tenday.setCost(333333333333.3);
		tenday.setStartDate("2");
		tenday.setEndDate("12");
		
		cout << tenday << endl;
	}
	catch (std::logic_error le) {
		cout << "set failed" << endl;
	}

	
	int x;
	cin >> x;

	return(0);
}