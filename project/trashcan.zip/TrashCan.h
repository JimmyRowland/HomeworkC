#ifndef TRASHCAN_H
#define TRASHCAN_H
#include <iostream>
#include <stdexcept>
using namespace std;

class OverflowingTrashCanException : public std::logic_error {
public:
	using std::logic_error::logic_error;
};
class UnderflowingTrashCanException : public std::logic_error {
public:
	using std::logic_error::logic_error;
};
class TrashCan {

private:
	bool myIsCovered;
	int my_Size;
	int my_Contents;
	static int numOfTrashCan;
public:
	TrashCan();
	TrashCan(int size);
	TrashCan(int size, int contents);

	void setSize(int size);
	int  getSize();
	int  getContents();


	void addItem();

	void empty();
	void cover();
	void uncover();

	void printCan(std::ostream& outs) const;
	void printCan() const;
	void removeContents();
	friend TrashCan operator + (const TrashCan& left, const TrashCan& right);
	friend TrashCan operator - (const TrashCan& left, const TrashCan& right);
	friend bool   operator ==(const TrashCan& left, const TrashCan& right);
	friend bool   operator >(const TrashCan& left, const TrashCan& right);
	friend bool   operator >=(const TrashCan& left, const TrashCan& right);
	friend bool   operator !=(const TrashCan& left, const TrashCan& right);
	friend bool   operator <(const TrashCan& left, const TrashCan& right);
	friend bool   operator <=(const TrashCan& left, const TrashCan& right);
	friend bool   operator ==(const TrashCan& left, const TrashCan& right);
	


	friend std::ostream& operator <<(std::ostream& outs, const TrashCan &n);
	friend std::istream& operator >> (std::istream& ins, TrashCan & n);
	friend std::ostream& operator <<(std::ostream& outs, const TrashCan * n);
	friend std::istream& operator >> (std::istream& ins, TrashCan * & n);
	bool trashCanExploded(int size, int content);
	bool notEnoughTrash(int size, int content);
	bool negativeSize(int size, int contents);
	~TrashCan();



};

#endif