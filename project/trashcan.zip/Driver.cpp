/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 12/4
o Project 16: Inherited Mailbox
o Input: 
o Output:
This trash can is destroyed
----some tests follow----
This trash can is destroyed
A TrashCan with a size=100 and containing 8 pieces of trash. There are 4 trash cans
A TrashCan with a size=5 and containing 0 pieces of trash. There are 4 trash cans
> is working...
!= is working...
< is working...
== is working...
This trash can is destroyed
---broken code follows---
got an exception...
got an exception...



*/
#include "TrashCan.h"
#include <iostream>
#include <stdexcept>
using namespace std;
int TrashCan::numOfTrashCan = 0;

int main() {

	TrashCan yours(5, 3);
	TrashCan mine(100, 3);
	yours.addItem();
	mine.addItem();
	TrashCan eightItems = mine + mine;

	cout << "----some tests follow----" << endl;
	try {
		TrashCan zeroItems = yours - yours;
		eightItems.printCan();
		zeroItems.printCan();
		if (eightItems > zeroItems) {
			cout << "> is working..." << endl;
		}
		if (eightItems != zeroItems) {
			cout << "!= is working..." << endl;
		}
		if (zeroItems < eightItems) {
			cout << "< is working..." << endl;
		}
		if (eightItems == eightItems) {
			cout << "== is working..." << endl;
		}
	}
	catch (std::logic_error le) {
		cout << "This should never run.";
		cout << "  Why?" << endl;
	}

	cout << "---broken code follows---" << endl;

	try {

		TrashCan negativeItems = mine -
			eightItems;
		cout << "This should never run.";
		cout << "Why?" << endl;

	}
	catch (UnderflowingTrashCanException utce) {
		cout << "got an exception..." << endl;
	}
	catch (std::logic_error le) {
		cout << "This should never run.";
		cout << "Why?" << endl;
	}

	try {

		TrashCan overfull = yours + yours;
		cout << "This should never run.";
		cout << "Why?" << endl;

	}
	catch (OverflowingTrashCanException utce) {
		cout << "got an exception..." << endl;
	}
	catch (std::logic_error le) {
		cout << "This should never run.";
		cout << "Why?" << endl;
	}
	
	
	int x;
	cin >> x;

	return(0);
}