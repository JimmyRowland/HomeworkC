#include "TrashCan.h"
#include <iostream>
#include <stdexcept>

TrashCan::TrashCan() {
	myIsCovered = false;
	my_Size = 0;
	my_Contents = 0;
	
	TrashCan::numOfTrashCan++;
}

TrashCan::TrashCan(int size) {
	TrashCan(size, 0);
}

TrashCan::TrashCan(int size, int contents) {




	
		if (negativeSize(size, contents) || notEnoughTrash(size, contents) || trashCanExploded(size, contents)) {

		}
		else {
			myIsCovered = false;
			my_Size = size;
			my_Contents = contents;
			TrashCan::numOfTrashCan++;
		}

	

	

}

void TrashCan::setSize(int size) {
	if (size < 0) {
		throw std::logic_error("Error: a negative number is stored as the size value!");
		return;
	}
	if (my_Contents > size) {
		throw std::logic_error("Error: Trash can will be exploded!");
		return;
	}
	my_Size = size;
}
void TrashCan::removeContents() {
	my_Contents -= 1;
}
int TrashCan::getSize() {
	return(my_Size);
}

int TrashCan::getContents() {
	return(my_Contents);
}

void TrashCan::addItem() {
	my_Contents = my_Contents + 1;
	try { trashCanExploded(my_Size, my_Contents); }
	catch (std::logic_error e) { throw std::logic_error(e.what()); }
	
}

void TrashCan::empty() {
	my_Contents = 0;
}

void TrashCan::cover() {
	myIsCovered = true;
}

void TrashCan::uncover() {
	myIsCovered = false;
}

void TrashCan::printCan(std::ostream& outs) const {
	using namespace std;
	if (! this) {
		cout << "Trying to print NULL TrashCan. Fail ta ta";
		return;
	}
	
	
	cout << "A TrashCan with a size=" << my_Size << " and containing " << my_Contents << " piece";
	if (my_Contents != 1) {
		cout << "s";
	}
	cout << " of trash" << ". There are " << numOfTrashCan << " trash cans" << endl;
}
void TrashCan::printCan() const {
	using namespace std;
	if (!this) {
		cout << "Trying to print NULL TrashCan. Fail ta ta";
		return;
	}


	cout << "A TrashCan with a size=" << my_Size << " and containing " << my_Contents << " piece";
	if (my_Contents != 1) {
		cout << "s";
	}
	cout << " of trash" << ". There are " << numOfTrashCan << " trash cans" << endl;
}
ostream& operator <<(ostream& outs,
	const TrashCan& n) {
	n.printCan(outs);
	return(outs);
}
ostream& operator <<(ostream& outs,
	const TrashCan* n) {
	n->printCan(outs);
	return(outs);
}

istream& operator >> (istream& ins,
	TrashCan& n) {
	int i = 0;
	ins >> i;
	n.setSize(i);
	return(ins);
}
istream& operator >> (istream& ins,
	TrashCan  *& n) {
	int i = 0;
	ins >> i;
	n->setSize(i);
	return(ins);
}
TrashCan operator+ (const TrashCan& left, const TrashCan& right) {
	TrashCan temp = TrashCan(left.my_Size, left.my_Contents + right.my_Contents);
	return(temp);
}
TrashCan operator- (const TrashCan& left, const TrashCan& right) {
	TrashCan temp = TrashCan(left.my_Size, left.my_Contents - right.my_Contents);
	return(temp);
}

bool operator== (const TrashCan& left, const TrashCan& right) {
	return(left.my_Contents == right.my_Contents);
}
bool operator!= (const TrashCan& left, const TrashCan& right) {
	return(left.my_Contents != right.my_Contents);
}
bool operator>= (const TrashCan& left, const TrashCan& right) {
	return(left.my_Contents >= right.my_Contents);
}
bool operator<= (const TrashCan& left, const TrashCan& right) {
	return(left.my_Contents <= right.my_Contents);
}
bool operator> (const TrashCan& left, const TrashCan& right) {
	return(left.my_Contents > right.my_Contents);
}
bool operator< (const TrashCan& left, const TrashCan& right) {
	return(left.my_Contents < right.my_Contents);
}

bool TrashCan::trashCanExploded(int size, int contents) {
	if (contents > size) {
		throw OverflowingTrashCanException("Error: Trash can will be exploded!");
		return true;
	}
	return false;
}
bool TrashCan::notEnoughTrash(int size, int contents) {
	if (contents < 0) {
		throw std::logic_error("Error: Run out of trash!");
		return true;
	}
	return false;
}
bool TrashCan::negativeSize(int size, int contents) {
	if (size < 0 || contents < 0) {
		throw UnderflowingTrashCanException("Error: a negative number is stored as the size value or content value!");
		return true;
	}
	return false;
}

TrashCan::~TrashCan() {
	cout << "This trash can is destroyed\n";

}
