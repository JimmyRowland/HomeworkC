#include "Doctor.h"
#include <iostream>
#include <stdexcept>
#include <string>

Doctor::Doctor(string docName, string docSpecialty) : name(docName),specialty(docSpecialty){
	
}

string Doctor::getName() const {
	return name;
}
string Doctor::getSpecialty() const {
	return specialty;
}
void Doctor::practice() {
	cout << getName() << " is practicing on a patient!" << endl;
}
