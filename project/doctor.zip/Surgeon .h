#ifndef SURGEON_H
#define SURGEON_H
#include "Doctor.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
class Surgeon : public Doctor {
public:
	Surgeon(string name = "Tom",string specialty = "Surgery");
	void practice();

};
#endif