#ifndef DOCTOR_H
#define DOCTOR_H
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
class Doctor {
public:
	
	Doctor(string name = "undefined", string specialty = "undefined");
	string getName() const;
	string getSpecialty() const;
	virtual void practice();
private:
	string name;
	string specialty;
};


#endif