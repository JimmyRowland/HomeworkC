/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 12/10
o Class Doctor
o Input: 
o Output:
a surgeon named Mary is in the operating room!
a surgeon named Tom is in the operating room!
I'm doctor is practicing on a patient!



*/
#include "Doctor.h"
#include "Surgeon .h"
#include <iostream>
#include <string>
using namespace std;


int main() {
	Doctor d("I'm doctor","video game");
	Surgeon s;
	Surgeon * mary = new Surgeon("Mary");
	mary->practice();
	s.practice();
	d.practice();
	int x;
	cin >> x;

	return(0);
}