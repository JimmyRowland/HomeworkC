#include "Doctor.h"
#include "Surgeon .h"
#include <iostream>
#include <stdexcept>
#include <string>
Surgeon::Surgeon(string name,string specialty) : Doctor(name, specialty){
	
}
void Surgeon::practice() {
	cout << "a surgeon named " << getName() << " is in the operating room!" << endl;
}