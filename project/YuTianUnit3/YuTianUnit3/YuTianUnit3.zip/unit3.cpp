/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 9/24
o Purpose:hello world
o Input:
o Output:
*/
#include <iostream>
using namespace std;
void main() {
	cout << "hello world" << endl;
	cin.get();
}