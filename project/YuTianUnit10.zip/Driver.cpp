#include "TrashCan.h"
#include <iostream>
using namespace std;


int main( ) {
	cout << "Welcome to Howie's TrashCan Program!" << endl;
	TrashCan myCan;
	TrashCan yourCan;

	yourCan.setSize( 12 );
	myCan.setSize( 12 );

	yourCan.addItem( );
	yourCan.addItem( );

	myCan.addItem( );

	myCan.printCan();
	yourCan.printCan();


	return( 0 );
}