#ifndef TRASHCAN_H
#define TRASHCAN_H
#include <iostream>
using namespace std;


class TrashCan {
public:
	TrashCan( );
	TrashCan( int size );
	TrashCan( int size, int contents );

	void setSize( int size );
	int  getSize( );
	int  getContents( );
	

	void addItem( );
	
	void empty( ); 
	void cover( );
	void uncover( );

	void printCan( );
	void setOwner(string owner);
	void removeContents();
	void setUser(string user);
	void changeUser(string owner);
	void changeOwner(string owner);
	void setPrice(double price);


private:
	bool myIsCovered;
	int my_Size;
	int my_Contents;
	bool recyclable;
	string owner;
	string user;
	double price;
};

#endif