#include "TrashCan.h"

TrashCan::TrashCan( ) {
	myIsCovered = false;
	my_Size = 0;
	my_Contents = 0;
}

TrashCan::TrashCan( int size ) {
	myIsCovered = false;
	my_Size = size;
	my_Contents = 0;
}

TrashCan::TrashCan( int size, int contents ) {
	myIsCovered = false;
	my_Size = size;
	my_Contents = contents;
}

void TrashCan::setSize( int size ) {
	my_Size = size;
}
void TrashCan::removeContents() {
	my_Contents -= 1;
}
int TrashCan::getSize( ) {
	return( my_Size );
}

int TrashCan::getContents( ) {
	return( my_Contents );
}

void TrashCan::addItem( ) {
	my_Contents = my_Contents + 1;
}
	
void TrashCan::empty( ) {
	my_Contents = 0;
}

void TrashCan::cover( ) {
	myIsCovered = true;
}

void TrashCan::uncover( ) {
	myIsCovered = false;
}

void TrashCan::printCan( ) {
	cout << "A TrashCan with a size=" << my_Size << " and containing " << my_Contents << " piece";
	if (my_Contents != 1) {
		cout << "s";
	}
	cout << " of trash" << endl;
}
void TrashCan::setOwner(string owner) {};
void TrashCan::setUser(string user) {};
void TrashCan::changeUser(string user) {};
void TrashCan::changeOwner(string owner) {};
void TrashCan::setPrice(double price) {};





