/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 11/13
o Project 13: Exception TrashCan
o Input:
o Output:
1	A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

subtraction failed
2	A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

constructor failed
3	A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

setSize failed
4	A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

constructor failed
5	A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans


*/
#include "TrashCan.h"
#include <iostream>
#include <stdexcept>
using namespace std;
int TrashCan::numOfTrashCan = 0;

int main() {

	TrashCan yours;
	TrashCan mine;
	TrashCan test;


	yours.setSize(10);
	mine.setSize(10);
	test.setSize(5);

	yours.addItem();
	mine.addItem();
	mine.addItem();
	mine.addItem();
	mine.addItem();
	mine.addItem();
	test.addItem();
	test.addItem();
	test.addItem();
	test.addItem();
	test.addItem();


	cout << "1	"<<test << endl;


	try {
		// contents will become negative...
		// an exception should get thrown
		test = yours - mine;
	}
	catch (std::logic_error le) {
		cout << "subtraction failed" << endl;
	}


	/// test should be unchanged
	cout << "2	" << test << endl;

	try {
		// how can you have a negative size
		// an exception should get thrown
		test = TrashCan(-100);
	}
	catch (std::logic_error le) {
		cout << "constructor failed" << endl;
	}

	/// test should be unchanged
	cout << "3	" << test << endl;

	try {
		// how can you have 5 pieces of 
		// trash in a can that
		// can only hold 3??
		// an exception should get thrown
		test.setSize(3);
	}
	catch (std::logic_error le) {
		cout << "setSize failed" << endl;
	}

	/// test should be unchanged
	cout << "4	" << test << endl;

	try {
		// how can you have a negative
		// contents value??
		test = TrashCan(10, -100);
	}
	catch (std::logic_error le) {
		cout << "constructor failed" << endl;
	}
	cout << "5	" << test << endl;
	int x;
	cin >> x;

	return(0);
}