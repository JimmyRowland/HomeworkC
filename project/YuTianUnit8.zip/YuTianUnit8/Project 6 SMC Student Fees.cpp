/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 10/8
o Purpose: Project 6: SMC Student Fees
o Input: 18, 0, 0, 0, 0, 0, 1, 6, 1, 1, 1, 1,1, 1, 18, 2, 1, 1, 1,0
o Output:	
SMC Fee Calculator
Enter number of units enrolled: 18
Is this Fall[0], Winter[1], Spring[2] or Summer[3] session: 0
Are you a state resident[0] or not[1]: 0
Want a parking decal? [1 for yes/0 for no]: 0
Want an AS sticker? [1 for yes/0 for no]: 0
Want an ID card? [1 for yes/0 for no]: 0
For Fall semester, your total fees are $ 847.00
Try again? [1=yes/0=no]: 1

SMC Fee Calculator
Enter number of units enrolled: 6
Is this Fall[0], Winter[1], Spring[2] or Summer[3] session: 1
Are you a state resident[0] or not[1]: 1
Want a parking decal? [1 for yes/0 for no]: 1
Want an AS sticker? [1 for yes/0 for no]: 1
Want an ID card? [1 for yes/0 for no]: 1
For Winter semester, your total fees are $ 2103.50
Try again? [1=yes/0=no]: 1

SMC Fee Calculator
Enter number of units enrolled: 18
Is this Fall[0], Winter[1], Spring[2] or Summer[3] session: 2
Are you a state resident[0] or not[1]: 1
Want a parking decal? [1 for yes/0 for no]: 1
Want an AS sticker? [1 for yes/0 for no]: 1
Want an ID card? [1 for yes/0 for no]: 1
For Spring semester, your total fees are $ 6166.50
Try again? [1=yes/0=no]: 0
*/
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;
void const outputTotalFees(double feesDue, string Semester) {
	cout << "For " << Semester << " semester, your total fees are $ " << setprecision(2) << fixed << feesDue << "\n";
}
int tryAgain() {
	int boolean;
	cout << "Try again? [1=yes/0=no]: ";
	cin >> boolean;
	if (boolean == 1) {
		cout << "\n\n";
		return 1;
	}

		
	return 0;
}
int whichSemester() {
	cout << "Is this Fall[0], Winter[1], Spring[2] or Summer[3] session: ";
	int semester;
	cin >> semester;
	switch (semester) {
	case 0:
	case 1:
	case 2:
	case 3:
		return semester;
	default: 
		cout << "please input 0,1,2,or 3\n";
		return whichSemester();

	}
}
void residentOrNot(double* feeDue, int units) {
	cout << "Are you a state resident[0] or not[1]: ";
	int identity;
	cin >> identity;
	switch (identity) {
	case 1:
		
		*feeDue += double(units) * 335.00;
		break;
	case 0:
		*feeDue += double(units) * 46.00;
		break;
	default:
		cout << "Please input 0, or 1 next time\n";
		residentOrNot(feeDue, units);
	}
}
string Student_Services_Fee_and_parking_decal(double* feeDue, int semester) {
	cout << "Want a parking decal? [1 for yes/0 for no]: ";
	int parking;
	cin >> parking;
	
	switch (semester) {
	case 0:
	case 2:
		
		switch (parking) {
		case 1:
			*feeDue += 85.00;
			break;
		case 0:
			break;
		default:
			cout << "Please input 0, or 1 next time\n";
			return Student_Services_Fee_and_parking_decal(feeDue, semester);

		}
		*feeDue += 51.50;
		break;
	case 1:
	case 3:
		switch (parking) {
		case 1:
			*feeDue += 45.00;
			break;
		case 0:
			break;
		default:
			cout << "Please input 0, or 1 next time\n";
			return Student_Services_Fee_and_parking_decal(feeDue, semester);

		}
		*feeDue += 48.50;
		break;

	}
	switch (semester) {
	case 0:
		return "Fall";
	case 1:
		return "Winter";
	case 2:
		return "Spring";
	case 3:
		return "Summer";
	}
}
void AS_sticker(double* feeDue) {
	cout << "Want an AS sticker? [1 for yes/0 for no]: ";
	int sticker;
	cin >> sticker;
	switch (sticker) {
	case 1:

		
		break;
	case 0:
		*feeDue -= 19.50;
		break;
	default:
		cout << "Please input 0, or 1 next time\n";
		AS_sticker(feeDue);
	}
}
void ID_card(double* feeDue) {
	cout << "Want an ID card? [1 for yes/0 for no]: ";
	int card;
	cin >> card;
	switch (card) {
	case 1:


		break;
	case 0:
		*feeDue -= 13;
		break;
	default:
		cout << "Please input 0, or 1 next time\n";
		ID_card(feeDue);
	}
}
int fees(int* units) {
	cout << "SMC Fee Calculator\n";
	
	cout << "Enter number of units enrolled: ";
	cin >> *units;
	double feeDue=0;
	int semester = whichSemester();
	residentOrNot(&feeDue, *units);
	string Semester = Student_Services_Fee_and_parking_decal(&feeDue, semester);
	AS_sticker(&feeDue);
	ID_card(&feeDue);
	outputTotalFees(feeDue, Semester);
	if (tryAgain()) {
		return fees(units);
	}
	cout << endl;
	return 0;
}


int main() {
	
	int units = 0;
	
	
	
	fees(&units);
	

	
	
	return 0;

}