#ifndef ELEVATOR
#define ELEVATOR
#include<string>
#include <iostream>
using namespace std;


class Elevator {
public:
	Elevator();
	Elevator(int passengers);
	Elevator(int passengers, int floor);
	void openDoors();
	void closeDoors();
	void letOffPassengers(int amount);
	void acceptPassengers(int amount);

	void requestFloor(int floor);
	bool isOnFloor(int floor);

	int getFloor();
	int getPassengers();
	void arriveRequestedFloor();

private:
	void outPut();
	bool my_DoorsOpen;
	int my_Passengers;
	int current_Floor;
	int requsted_floor;
	
};

#endif