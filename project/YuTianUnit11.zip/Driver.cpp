/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 10/15
Project 9: Elevator
o Input:
o Output:
Elevator on Floor 1 with 0 passengers
Elevator Door's Open
Elevator has 5 passengers
Passengers want floor 3
Elevator Door's closed
Elevator moving to floor 3
Elevator Door's Open
Elevator has 4 passengers
Elevator has 6 passengers
Passengers want floor 4
Elevator Door's closed
Elevator moving to floor 4
Elevator Door's Open
Elevator has 3 passengers
*/
#include "elevator.h"
#include <iostream>
using namespace std;


int main( ) {
	Elevator e;
	e.openDoors();
	e.acceptPassengers(5);
	e.requestFloor(3);
	e.closeDoors();
	e.arriveRequestedFloor();
	e.openDoors();
	e.letOffPassengers(1);
	e.acceptPassengers(2);
	e.requestFloor(4);
	e.closeDoors();
	e.arriveRequestedFloor();
	e.openDoors();
	e.letOffPassengers(3);
	int a;
	cin >> a;
	cout << endl;
	return(0);


	
}