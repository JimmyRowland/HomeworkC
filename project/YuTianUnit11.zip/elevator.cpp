#include "elevator.h"
Elevator::Elevator() {
	my_Passengers = 0;
	my_DoorsOpen = false;
	current_Floor = 1;
	cout << "Elevator on Floor " << current_Floor << " with " << my_Passengers << " passengers" << "\n";
};
Elevator::Elevator(int passengers) {
	my_Passengers = passengers;
	my_DoorsOpen = false;
	current_Floor = 1;
	cout << "Elevator on Floor " << current_Floor << " with " << my_Passengers << " passengers" << "\n";
};
Elevator::Elevator(int passengers, int floor) {
	my_Passengers = passengers;
	my_DoorsOpen = false;
	current_Floor = floor;
	cout << "Elevator on Floor " << current_Floor << " with " << my_Passengers << " passengers";
};
void Elevator::openDoors() {
	
	if (my_DoorsOpen) {
		cout << "door has already been opened" << "\n";
	}
	else {
		my_DoorsOpen = true;
		cout << "Elevator Door's Open" << "\n";
	}
};
void Elevator::closeDoors() {
	if (my_DoorsOpen) {
		my_DoorsOpen = false;
		cout << "Elevator Door's closed" << "\n";
	}
	else {
		
		cout << "door has already been closed" << "\n";
	}
}
	;
void Elevator::letOffPassengers(int amount) {
	if (my_DoorsOpen) {
		my_Passengers -= amount;
		cout << "Elevator has " << my_Passengers << " passengers" << "\n";
	}
	else {
		cout << "You missed your floor" << "\n";
	}
};
void Elevator::acceptPassengers(int amount) {
	if (my_DoorsOpen) {
		my_Passengers += amount;
		cout << "Elevator has "<< my_Passengers<<" passengers" << "\n";
	}
	else {
		cout << "too late" << "\n";
	}

};

void Elevator::requestFloor(int floor) {
	
	requsted_floor = floor;
	cout << "Passengers want floor " << requsted_floor << "\n";
};
bool Elevator::isOnFloor(int floor) {
	if (current_Floor == floor) {
		return true;
	}
	else {
		return false;
	}
};

int Elevator::getFloor() {
	return current_Floor;
};
int Elevator::getPassengers() {
	return my_Passengers;
};
void Elevator::arriveRequestedFloor() {
	current_Floor = requsted_floor;
	cout << "Elevator moving to floor " << current_Floor << "\n";
}
void Elevator::outPut() {
	string door;
	if (my_DoorsOpen)
		door = "open";
	else
		door = "closed";
	cout << "There are " << my_Passengers << " passengers on board. Door is " << door << ". Elevator is currently on" << current_Floor << "floor."<< "\n";
}




