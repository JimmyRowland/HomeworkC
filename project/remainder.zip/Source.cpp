/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 11/13
o Purpose: Project 11: Remainder
o Input: 
o Output:
1
1
1
20
20
20


*/
#include <iostream>
#include <string>
#include <fstream>
#include "Remainder.h"

using namespace std;

int main() {

	Remainder ten(5, 2);
	cout << ten.RecursiveARemainderB() << endl;
	cout << ten.IterativeARemainderB() << endl;
	cout << ten.RecursiveARemainderB() << endl;

	Remainder twenty(41, 21);
	cout << twenty.RecursiveARemainderB() << endl;
	cout << twenty.IterativeARemainderB() << endl;
	cout << twenty.RecursiveARemainderB() << endl;
	int x;
	cin >> x;




	return 0;

}