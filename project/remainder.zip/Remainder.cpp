#include "Remainder.h"
#include <iostream>
#include <stdexcept>
using namespace std;
Remainder::Remainder() {

	myValueofA = 2;
	myValueofB = 2;
}

Remainder::Remainder(int a) {

	myValueofA = a;
	myValueofB = 2;
}

Remainder::Remainder(int a, int b) {

	myValueofA = a;
	myValueofB = b;
}


int Remainder::getA() const {
	return(myValueofA);
}

int Remainder::getB() const {
	return(myValueofB);
}

int Remainder::IterativeARemainderB() const {
	int temp = myValueofA;
	if (myValueofA == 0 || myValueofB == 0 || myValueofA < 0) {
		return 0;
	}
	else {
		while (temp > myValueofB) {
			temp -= myValueofB;
		}
		return temp;
	}
}

int Remainder::remainder(int a, int b) const {
	if (a == 0 || b == 0 || a < 0) return(0);
	else if (a < b) return(a);
	else return(remainder(a - b, b));
}

int Remainder::RecursiveARemainderB() const {

	return remainder(getA(), getB());
}

Remainder::~Remainder() {
	cout << "This Remainder is destroyed\n";

}
