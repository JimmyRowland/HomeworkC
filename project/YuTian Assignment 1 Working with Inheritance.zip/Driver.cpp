#include "Shape.h"
#include "Triangle.h"
#include "Rectangle.h"
#include "Square.h"
#include "Circle.h"
#include "Ellipse.h"
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
using namespace cs20a;


int main() {
	Triangle t(3, 4, 5);
	Square s(4);
	Rectangle r(3, 2);
	Circle c(3);
	Ellipse e(3, 3);
	Shape *shp[] = { &t, &s, &r, &c, &e };
	for (int i = 0; i < 5; i++) {
		cout << shp[i]->getDescription() << endl;
		cout << "area = " << shp[i]->area() << endl;
		cout << "circumference = " << shp[i]->circumference() << endl << endl;
	}

	int x;
	cin >> x;

	return(0);
}