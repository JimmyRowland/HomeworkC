#pragma once
#include "Ellipse.h"
namespace cs20a {
	class Circle :public Ellipse {
	public:
		Circle(double r);
		virtual double circumference();
		virtual std::string getDescription();


	};
}
