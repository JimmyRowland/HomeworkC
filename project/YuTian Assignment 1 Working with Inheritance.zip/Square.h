#pragma once
#include "Rectangle.h"
namespace cs20a {
	class Square :public Rectangle {
	public:
		Square(double s);
		virtual std::string getDescription();

	};
}
