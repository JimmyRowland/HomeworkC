#include "Ellipse.h"
#include <iostream>
#include <string>
#include <math.h>

namespace cs20a {
	Ellipse::Ellipse(double majorAxis, double minorAxis) : Shape(), a(majorAxis), b(minorAxis) {}
	double Ellipse::area() {
		return pi*a*b;
	}
	double Ellipse::circumference() {
		return pi*(3 * (a + b) - sqrt((3 * a + b)*(a + 3 * b)));
	}
	std::string Ellipse::getDescription() {
		return "Ellipse with major axis = " + std::to_string(a) + ", and minor axis = " + std::to_string(b);
	}
	Ellipse::~Ellipse() {
		std::cout << getDescription() << " is destroyed" << std::endl;
	}
}