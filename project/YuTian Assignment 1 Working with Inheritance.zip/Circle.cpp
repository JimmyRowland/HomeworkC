#include "Circle.h"
#include <iostream>
#include <string>
#include <math.h>

namespace cs20a {
	Circle::Circle(double radius) : Ellipse(radius, radius){}

	double Circle::circumference() {
		return pi*2*a;
	}
	std::string Circle::getDescription() {
		return "Circle with radius = " + std::to_string(a);
	}
}