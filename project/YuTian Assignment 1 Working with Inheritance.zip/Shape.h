#pragma once
#include <string>
namespace cs20a
{
	class Shape {
	public:
		Shape();
		virtual double area() = 0;
		virtual double circumference() = 0;
		virtual std::string getDescription();
		~Shape();
	};
};



