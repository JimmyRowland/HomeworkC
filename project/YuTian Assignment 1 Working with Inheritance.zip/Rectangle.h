#pragma once
#include "Shape.h"
namespace cs20a {
	class Rectangle :public Shape {
	public:
		Rectangle(double s1, double s2);
		virtual double area();
		virtual double circumference();
		virtual std::string getDescription();
		~Rectangle();
	protected:
		double s1, s2;

	};
}
