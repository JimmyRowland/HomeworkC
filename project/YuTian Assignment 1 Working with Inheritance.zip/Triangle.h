#pragma once
#include "Shape.h"
namespace cs20a {
	class Triangle :public Shape {
	public:
		Triangle(double s1, double s2, double s3);
		virtual double area();
		virtual double circumference();
		virtual std::string getDescription();
		~Triangle();
	protected:
		double s1, s2, s3;

	};
}
