#include "Shape.h"
#include <iostream>
#include <stdexcept>
#include <string>
namespace cs20a {
	Shape::Shape(){}
	std::string Shape::getDescription() {
		return "undefined shape";
	}
	Shape::~Shape() {
		printf("Shape is destroyed");
	}
}
