#include "Triangle.h"
#include <iostream>
#include <string>
#include <math.h>

namespace cs20a {
	Triangle::Triangle(double side1,double side2, double side3) : Shape(), s1(side1), s2(side2), s3(side3){}
	double Triangle::area() {
		double sx = (s1 + s2 + s3) / 2;
		return sqrt(sx*(sx - s1)*(sx - s2)*(sx - s3));
	}
	double Triangle::circumference(){
		return s1 + s2 + s3;
	}
	std::string Triangle::getDescription() {
		return "triangle with side1 = " + std::to_string(s1) + ", side2 = " + std::to_string(s2) + ", and side3 = " + std::to_string(s3);
	}
	Triangle::~Triangle() {
		std::cout << getDescription() << " is destroyed" << std::endl;
	}
}