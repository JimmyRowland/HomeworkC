#pragma once
#include "Shape.h"
namespace cs20a {
	class Ellipse :public Shape {
	public:
		Ellipse(double a, double b);
		virtual double area();
		virtual double circumference();
		virtual std::string getDescription();
		~Ellipse();
	protected:
		double a, b;
		const double pi = acos(-1);
	};
}
