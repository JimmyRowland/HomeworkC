#include "Rectangle.h"
#include <iostream>
#include <string>

namespace cs20a {
	Rectangle::Rectangle(double side1, double side2) : Shape(), s1(side1), s2(side2) {}
	double Rectangle::area() {
		
		return s1*s2;
	}
	double Rectangle::circumference() {
		return (s1 + s2)*2;
	}
	std::string Rectangle::getDescription() {
		return "Rectangle with side1 = " + std::to_string(s1) + ", and side2 = " + std::to_string(s2);
	}
	Rectangle::~Rectangle() {
		std::cout << getDescription() << " is destroyed" << std::endl;
	}
}