#include "Square.h"
#include <iostream>
#include <string>

namespace cs20a {
	Square::Square(double side) : Rectangle(side,side){}

	std::string Square::getDescription() {
		return "Square with side = " + std::to_string(s1);
	}
}