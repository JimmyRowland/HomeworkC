#include "Door.h"
#include "DoorKnob.h"
#include <iostream>
#include <stdexcept>
#include <string>

Door::Door(bool lockable, bool unlocked){
	myKnob = DoorKnob(lockable, !unlocked);
}

void Door::open() {
	myKnob.turn();
	myKnob.push();
}
void Door::close() {
	myKnob.turn();
	myKnob.pull();
}
