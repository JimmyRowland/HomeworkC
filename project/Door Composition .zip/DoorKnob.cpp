#include "DoorKnob.h"
#include <iostream>
#include <stdexcept>
#include <string>
DoorKnob::DoorKnob() {
	myIsLockable = false;
	myIsLocked = false;
}

DoorKnob::DoorKnob(bool isLockable, bool Islocked) {
	myIsLockable = isLockable;
	myIsLocked = Islocked;
}

void DoorKnob::turn() {
	if (!myIsLocked) {
		cout << "turning knob..." << endl;
	}
	else
		cout << "knob is locked!" << endl;
}

void DoorKnob::push() {
	if (!myIsLocked) {
		cout << "pushing knob..." << endl;
	}
	else
		cout << "knob is locked!" << endl;
}

void DoorKnob::pull() {
	if (!myIsLocked) {
		cout << "pulling knob..." << endl;
	}
	else
		cout << "knob is locked!" << endl;
}

bool DoorKnob::canBeLocked() const {
	return(myIsLockable);
}

void DoorKnob::lock() {
	if (myIsLockable) { myIsLocked = true; }
}

void DoorKnob::unlock() {
	if (myIsLockable) { myIsLocked = false; }
}