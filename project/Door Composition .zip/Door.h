#ifndef DOOR_H
#define DOOR_H
#include "DoorKnob.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
class Door {
public:
	
	Door(bool isLockable = true, bool unlocked = false);
	void open();
	void close();
private:
	DoorKnob myKnob;
};


#endif