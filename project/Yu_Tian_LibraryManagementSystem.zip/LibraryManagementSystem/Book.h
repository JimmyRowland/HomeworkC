#pragma once
#include <iostream>
#include <string>

namespace cs20a {
	using namespace std;
	class Book
	{
	public:
		Book();
		Book(string author, string title, int copies = 1, int checkedOut = 0);

		string getAuthor() const;
		string getTitle() const;

		void setAuthor(string author);
		void setTitle(string title);

		int getCopies() const;
		int getCheckedOut() const;

		void addCopy();
		void deleteCopy();

		void checkOut();
		void checkIn();

		friend  ostream& operator << (ostream& outs, const Book& book);

	private:
		string author, title;
		int copies, checkedOut;
	};
}