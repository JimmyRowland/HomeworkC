#pragma once
#include <iostream>
#include <string>
#include "Book.h"
#include "DynamicArray.h"

namespace cs20a {
	class Library {
	public:
		Library();

		void addBook(string author, string title);
		void deleteBook(string author, string title);

		void checkOutBook(string author, string title);
		void checkInBook(string author, string title);

		int getTotalBooks() const;
		bool hasBook(string author, string title) const;

		friend ostream& operator << (ostream& outs, const Library& library);

	private:
		DynamicArray<Book> books;
		int findBook(string author, string title) const;
	};
}