#pragma once
#include <stdexcept>
namespace cs20a
{
	template<class T>
	class DynamicArray
	{
	public:
		DynamicArray();
		DynamicArray(int capacity);
		DynamicArray(const DynamicArray<T> &rhs);

		~DynamicArray();

		void add(const T& value);
		void removeAt(int index);
		void insert(int index, const T& value);
		bool remove(const T& value);

		int indexOf(const T& value) const;
		bool contains(const T& value) const;

		void clear();

		int getSize() const;
		int getCapacity() const;

		bool isEmpty() const;

		DynamicArray<T>& operator =(const DynamicArray<T>& rhs);

		T& operator[](int index);
		const T& operator[](int index) const;

		bool operator==(DynamicArray<T> & a) const;
		bool operator!=(DynamicArray<T> & a) const;

		const int INITIAL_CAPACITY = 2;
		const int GROWTH_FACTOR = 2;
		const double MINIMUM_SIZE_ALLOWED = 0.25;

	private:
		int size, capacity;
		T *elements;

		void deepCopy(const DynamicArray<T>& rhs);
		void setCapacity(int newCapacity);
		bool isCapacityAdjustmentNeeded() const;
		bool isIndexInRange(int index) const;
	};

	template<class T>
	DynamicArray<T>::DynamicArray() : size(0), capacity(INITIAL_CAPACITY)
	{
		elements = new T[capacity];
	}

	template<class T>
	DynamicArray<T>::DynamicArray(int capacity) : size(0), capacity(capacity)
	{
		elements = new T[capacity];
	}

	template<class T>
	DynamicArray<T>::DynamicArray(const DynamicArray<T> &rhs)
	{
		deepCopy(rhs);
	}

	template <class T>
	DynamicArray<T>& DynamicArray<T>::operator =(const DynamicArray<T>& rhs) {
		if (this != &rhs) {
			delete[] elements;
			deepCopy(rhs);
		}
		return *this;
	}

	template<class T>
	void DynamicArray<T>::deepCopy(const DynamicArray<T>& rhs)
	{
		size = rhs.size;
		capacity = rhs.capacity;
		elements = new T[capacity];

		for (int i = 0; i < size; i++)
			elements[i] = rhs.elements[i];
	}

	template<class T>
	DynamicArray<T>::~DynamicArray()
	{
		delete[] elements;
	}

	template<class T>
	void DynamicArray<T>::add(const T& value)
	{
		if (isCapacityAdjustmentNeeded())
			setCapacity(size + 1);

		T item = value;
		elements[size++] = item;
	}

	template<class T>
	void DynamicArray<T>::removeAt(int index)
	{
		if (!isIndexInRange(index))
			throw std::out_of_range("Index out of range.");

		for (int i = index; i < (size - 1); i++)
			elements[i] = elements[i + 1];

		size--;

		if (isCapacityAdjustmentNeeded())
			setCapacity(size + 1);
	}

	template<class T>
	bool DynamicArray<T>::remove(const T& value)
	{
		int i = indexOf(value);

		if (i >= 0) {
			removeAt(i);
			return true;
		}
		else
			return false;
	}

	template<class T>
	void DynamicArray<T>::insert(int index, const T& value)
	{
		if (!isIndexInRange(index))
			throw std::out_of_range("Index out of range.");

		if (isCapacityAdjustmentNeeded())
			setCapacity(size + 1);

		for (int i = size; i > index; i--)
			elements[i] = elements[i - 1];

		elements[index] = value;
		size++;
	}

	template<class T>
	int DynamicArray<T>::indexOf(const T& value) const
	{
		for (int i = 0; i < size; i++)
			if (elements[i] == value)
				return i;

		return -1;
	}

	template<class T>
	bool DynamicArray<T>::contains(const T& value) const
	{
		return indexOf(value) > -1;
	}

	template<class T>
	int DynamicArray<T>::getSize() const
	{
		return size;
	}

	template<class T>
	int DynamicArray<T>::getCapacity() const
	{
		return capacity;
	}

	template<class T>
	bool DynamicArray<T>::operator==(DynamicArray<T> & rhs) const
	{
		if (this != &rhs) {
			if (rhs.size != size)
				return false;

			for (int i = 0; i < size; i++)
				if (rhs[i] != elements[i])
					return false;
		}

		return true;
	}

	template<class T>
	bool DynamicArray<T>::operator!=(DynamicArray<T>& rhs) const
	{
		return !(this == &rhs);
	}

	template<class T>
	bool DynamicArray<T>::isCapacityAdjustmentNeeded() const
	{
		return !((size + 1) > MINIMUM_SIZE_ALLOWED*capacity && size < capacity);
	}

	template<class T>
	bool DynamicArray<T>::isIndexInRange(int index) const
	{
		return (index >= 0 && index <= (size - 1));
	}

	template<class T>
	void DynamicArray<T>::setCapacity(int minCapacity)
	{
		if (minCapacity < size)
			throw std::logic_error("Capacity must be greater than current size.");

		if (minCapacity >= 0)
		{
			int limit = 1;
			while (limit <= minCapacity)
				limit *= GROWTH_FACTOR;

			T *tarray = new T[limit];

			for (int i = 0; i < size; i++)
				tarray[i] = elements[i];

			delete[] elements;

			elements = tarray;
			capacity = limit;
		}
	}

	template<class T>
	T& DynamicArray<T>::operator[](int index)
	{
		if (!isIndexInRange(index))
			throw std::out_of_range("Index out of range.");

		return elements[index];
	}

	template<class T>
	const T& DynamicArray<T>::operator[](int index) const
	{
		if (!isIndexInRange(index))
			throw std::out_of_range("Index out of range.");

		return elements[index];
	}

	template<class T>
	void DynamicArray<T>::clear()
	{
		delete[] elements;

		size = 0;
		capacity = INITIAL_CAPACITY;
		elements = new T[capacity];
	}

	template<class T>
	bool DynamicArray<T>::isEmpty() const
	{
		return (size == 0);
	}
}