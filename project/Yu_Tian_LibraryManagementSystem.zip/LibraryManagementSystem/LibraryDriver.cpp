#include <iostream>
#include "Library.h"
#include "Book.h"

using namespace std;
using namespace cs20a;

int main()
{
	Library library;

	try
	{
		cout << "--> Before Initial State." << endl;

		library.addBook("Ernest Hemingway", "For Whom the Bell Tolls");
		library.addBook("Ernest Hemingway", "For Whom the Bell Tolls");
		library.addBook("John Steinbeck", "The Grapes of Wrath");
		library.addBook("John Steinbeck", "The Grapes of Wrath");
		library.addBook("John Steinbeck", "East of Eden");
		library.addBook("Mark Twain", "Huckleberry Finn");

		cout << library;
	}
	catch (const std::exception& e)
	{
		cout << "*** " << e.what() << " ***" << endl;
	}
	cout << "--> After Initial State." << endl << endl;

	try
	{
		cout << "--> Before deleting Main Street and For Whom the Bell Tolls." << endl;

		if (library.hasBook("Sinclair Lewis", "Main Street"))
			library.deleteBook("Sinclair Lewis", "Main Street");

		library.deleteBook("Ernest Hemingway", "For Whom the Bell Tolls");
		library.deleteBook("Ernest Hemingway", "For Whom the Bell Tolls");

		cout << library;
	}
	catch (const std::exception& e)
	{
		cout << "*** " << e.what() << " ***" << endl;
	}
	cout << "--> After deleting Main Street and For Whom the Bell Tolls." << endl << endl;

	try
	{
		cout << "--> Before checking out For Whom the Bell Tolls and The Grapes of Wrath." << endl;

		if (library.hasBook("Ernest Hemingway", "For Whom the Bell Tolls"))
			library.checkOutBook("Ernest Hemingway", "For Whom the Bell Tolls");

		if (library.hasBook("John Steinbeck", "The Grapes of Wrath"))
			library.checkOutBook("John Steinbeck", "The Grapes of Wrath");

		cout << library;
	}
	catch (const std::exception& e)
	{
		cout << "*** " << e.what() << " ***" << endl;
	}
	cout << "--> After checking out For Whom the Bell Tolls and The Grapes of Wrath." << endl << endl;

	try
	{
		cout << "--> Before checking checking in For Whom the Bell Tolls." << endl;

		library.checkInBook("Ernest Hemingway", "For Whom the Bell Tolls");
		library.checkInBook("Ernest Hemingway", "For Whom the Bell Tolls");

		cout << library;
	}
	catch (const std::exception& e)
	{
		cout << "*** " << e.what() << " ***" << endl;
	}
	cout << "--> After checking checking in For Whom the Bell Tolls." << endl << endl;

	try
	{
		cout << "--> Before checking in The Grapes of Wrath." << endl;

		library.checkInBook("John Steinbeck", "The Grapes of Wrath");

		cout << library;
	}
	catch (const std::exception& e)
	{
		cout << "*** " << e.what() << " ***" << endl;
	}
	cout << "--> After checking in The Grapes of Wrath." << endl << endl;

	try
	{
		cout << "--> Before checking in Huckleberry Finn." << endl;

		library.checkInBook("Mark Twain", "Huckleberry Finn");
		cout << endl;

		cout << library;
	}
	catch (const std::exception& e)
	{
		cout << "*** " << e.what() << " ***" << endl;
	}
	cout << "--> After checking in Huckleberry Finn." << endl << endl;

	system("pause");
	return 0;
}