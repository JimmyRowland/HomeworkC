#include <stdexcept>
#include "Library.h"

namespace cs20a {
	Library::Library()
	{}

	void Library::addBook(string author, string title)
	{
		//std::cout <<"bookIndex" <<findBook(author, title)<< "\n";
		if (hasBook(author,title)) {
			//std::cout << "addbook " << author << title << "\n";
			books[findBook(author, title)].addCopy();
		}
		else {
			Book newBook = Book(author, title);
			books.add(newBook);
		}
		//std::cout << "size " << books.getSize() << "\n";
	}

	void Library::deleteBook(string author, string title)
	{
		//Book bookToBeRemoved = Book(author, title);
		//books.remove(bookToBeRemoved);
		if (hasBook(author, title)) {
			//std::cout << author << " " << title << " is deleted\n";
			books[findBook(author, title)].deleteCopy();
			if(books[findBook(author, title)].getCopies()==0)
			books.removeAt(findBook(author, title));
		}
		else {
			std::cout << author <<" "<< title << " does not exist\n";
		}
		
	}

	void Library::checkOutBook(string author, string title)
	{
		//std::cout << author << " " << title << " check out\n";
		if (hasBook(author, title))
		books[findBook(author,title)].checkOut();
		else throw std::logic_error(author + " " + title + " does not exist");
	}

	void Library::checkInBook(string author, string title)
	{
		//std::cout << author << " " << title << " check in\n";
		if(hasBook(author,title))
		books[findBook(author, title)].checkIn();
		else throw std::logic_error(author + " " + title + " does not exist");
	}

	int Library::getTotalBooks() const
	{
		int total = 0;
		for (int i = 0; i < books.getSize(); i++) {
			total += books[i].getCopies();
		}
		//cout <<"total " <<total << endl;
		return books.getSize();
		//return total;
	}

	bool Library::hasBook(string author, string title) const
	{	
		return findBook(author, title)!=-1;
	}

	int Library::findBook(string author, string title) const
	{
		for (int i = 0; i < books.getSize(); i++) {
			if (books[i].getAuthor() == author && books[i].getTitle() == title) {
				return i;
			}
		}
		return -1;
	}

	ostream & operator<<(ostream & outs,  const Library & library) 
	{
		for (int i = 0; i < library.getTotalBooks(); i++)
			outs << library.books[i] << endl;

		return outs;
	}

	//*** Code goes here ***//
	//*** Code goes here ***//
	//*** Code goes here ***//

}