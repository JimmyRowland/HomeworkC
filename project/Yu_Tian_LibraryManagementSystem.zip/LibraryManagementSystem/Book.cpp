#include <stdexcept>
#include "Book.h"

namespace cs20a {
	Book::Book() : author(), title(), copies(1), checkedOut(0)
	{}

	Book::Book(string author, string title, int copies, int checkedOut) 
			: author(author), title(title), copies(copies), checkedOut(checkedOut)
	{}

	string Book::getAuthor() const
	{
		return string(author);
	}

	string Book::getTitle() const
	{
		return string(title);
	}

	void Book::setAuthor(string author)
	{
		this->author = author;
	}

	void Book::setTitle(string title)
	{
		this->title = title;
	}

	int Book::getCopies() const
	{
		return copies;
	}

	int Book::getCheckedOut() const
	{
		return checkedOut;
	}

	void Book::addCopy()
	{
		copies++;
	}

	void Book::deleteCopy()
	{
		if (copies > 0) copies--;
		else throw std::logic_error("out of copies");
	}

	void Book::checkOut()
	{
		if (getCheckedOut() >= getCopies()) throw std::logic_error("All books are already checked out");
		else
		{
			checkedOut++;
		}
	}

	void Book::checkIn()
	{
		if (getCheckedOut() <= 0) throw std::logic_error("The book is not belonged to library");
		else
		{
			checkedOut--;
		}
	}

	ostream & cs20a::operator<<(ostream & outs, const Book & book)
	{
		cout << book.title << ", by " << book.author << " Copies: "
			<< book.copies << " Checked out: " << book.checkedOut;
		return outs;
	}

	//*** Code goes here ***//
	//*** Code goes here ***//
	//*** Code goes here ***//

}