#include "Grader.h"
#include <iostream>
#include <stdexcept>
#include <algorithm> 
using namespace std;
Grader::Grader() {

	myValuesSeenSoFar = 0;
}

void Grader::addScore(int a) {
	if (myValuesSeenSoFar + 1 > 99) {
		cout << "array exploded";
		clear();
		return;
	}
	
	myValues[myValuesSeenSoFar] = a;
	myValuesSeenSoFar++;
}

void Grader::addScore(double a) {
	if (myValuesSeenSoFar + 1 > 99) {
		cout << "array exploded";
		clear();
		return;
	}
	myValues[myValuesSeenSoFar] = (int)a;
	myValuesSeenSoFar++;
}
void Grader::addScores(int array[], int size) {
	if (myValuesSeenSoFar + size > 99) {
		cout << "array exploded";
		clear();
		return;
	}
	for (int i = 0; i < size; i++) {
		addScore(array[i]);
	}
}
void Grader::addScores(double array[], int size) {
	if (myValuesSeenSoFar + size > 99) {
		cout << "array exploded";
		clear();
		return;
	}
	for (int i = 0; i < size; i++) {
		addScore(array[i]);
	}
}
int* Grader::copyArray() const {
	int array[100];
	copy(myValues, myValues + myValuesSeenSoFar, array);
	//cout << array[0] << " " << array[1] << " " << array[myValuesSeenSoFar - 1] << " " << myValuesSeenSoFar << " " << array[myValuesSeenSoFar];
	sort(array, array + myValuesSeenSoFar);
	
	return array;

}

int Grader::findBiggest() const {
	
	return copyArray()[myValuesSeenSoFar-1];

}

int Grader::findSmallest() const {
	//cout << myValues[0];
	return copyArray()[0];
}

void  Grader::clear() {
	myValuesSeenSoFar = 0;
	memset(myValues, 0, myValuesSeenSoFar + 1);
}

Grader::~Grader() {
	cout << "This Grader is destroyed\n";

}
