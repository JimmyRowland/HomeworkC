/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 11/13
o Purpose: Project 12: Grader
o Input: 
o Output:
Best Score = 99
75Worst Score = 70
Best Score = 100
50Worst Score = 50


*/
#include <iostream>
#include <string>
#include <fstream>
#include "Grader.h"

using namespace std;

int main() {

	Grader g;
	double d[5] = { 99,70,85,93,84 };
	double e[4] = { 100,81,60,91 };

	g.addScore(75);
	g.addScore(82);
	g.addScores(d, 5);

	cout << "Best Score = " << g.findBiggest() << endl;
	/// should give value 99
	cout << "Worst Score = " << g.findSmallest() << endl;
	/// should give value 70
	g.clear();

	g.addScore(50);
	g.addScore(74);
	g.addScores(e, 4);

	cout << "Best Score = " << g.findBiggest() << endl;
	/// should give value 100
	cout << "Worst Score = " << g.findSmallest() << endl;
	/// should give value 50
	int x;
	cin >> x;
	cout << endl;


	return 0;

}