#ifndef GRADER_H
#define GRADER_H
#include <iostream>


class Grader {

private:
	int myValues[100];
	int myValuesSeenSoFar;
public:
	Grader();

	void addScore(int score);
	void addScores(int scores[],
		int size);
	void addScore(double score);
	void addScores(double scores[],
		int size);
	void clear();
	int* copyArray() const;
	int findBiggest() const;
	int findSmallest() const;


	~Grader();



};

#endif