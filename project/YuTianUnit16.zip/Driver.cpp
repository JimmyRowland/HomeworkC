/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 11/26
o Project 14: Pointer TrashCan
o Input: 5
o Output:
A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

subtraction failed
A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

constructor failed
A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

setSize failed
A TrashCan with a size=5 and containing 5 pieces of trash. There are 3 trash cans

constructor failed
Trying to print NULL TrashCan. Fail ta ta
A TrashCan with a size=10 and containing 1 piece of trash. There are 4 trash cans

A TrashCan with a size=5 and containing 1 piece of trash. There are 4 trash cans

A TrashCan with a size=5 and containing 2 pieces of trash. There are 4 trash cans

This trash can is destroyed


*/
#include "TrashCan.h"
#include <iostream>
#include <stdexcept>
using namespace std;
int TrashCan::numOfTrashCan = 0;

int main() {

	TrashCan yours;
	TrashCan mine;
	TrashCan test;


	yours.setSize(10);
	mine.setSize(10);
	test.setSize(5);

	yours.addItem();
	mine.addItem();
	mine.addItem();
	mine.addItem();
	mine.addItem();
	mine.addItem();
	test.addItem();
	test.addItem();
	test.addItem();
	test.addItem();
	test.addItem();


	cout << test << endl;


	try {
		// contents will become negative...
		// an exception should get thrown
		test = yours - mine;
	}
	catch (std::logic_error le) {
		cout << "subtraction failed" << endl;
	}


	/// test should be unchanged
	cout << test << endl;

	try {
		// how can you have a negative size
		// an exception should get thrown
		test = TrashCan(-100);
	}
	catch (std::logic_error le) {
		cout << "constructor failed" << endl;
	}

	/// test should be unchanged
	cout << test << endl;

	try {
		// how can you have 5 pieces of 
		// trash in a can that
		// can only hold 3??
		// an exception should get thrown
		test.setSize(3);
	}
	catch (std::logic_error le) {
		cout << "setSize failed" << endl;
	}

	/// test should be unchanged
	cout << test << endl;

	try {
		// how can you have a negative
		// contents value??
		test = TrashCan(10, -100);
	}
	catch (std::logic_error le) {
		cout << "constructor failed" << endl;
	}

	TrashCan * ptrCan = new TrashCan(10, 1);
	TrashCan * nullCan = NULL;
	if (!nullCan) {
		nullCan = new TrashCan();
	}
	// be careful...
	try{ nullCan->addItem(); }
	catch (std::logic_error le) {
		cout << le.what() << endl;
	}
	
	cout << nullCan << endl;
	cout << ptrCan << endl;

	cin >> ptrCan;
	// notice the difference
	cout << ptrCan << endl;
	ptrCan->addItem();
	// notice the difference
	cout << ptrCan << endl;

	delete(ptrCan);
	// do you realize why I can't say:
	// delete( nullCan ); 
	
	
	
	int x;
	cin >> x;

	return(0);
}