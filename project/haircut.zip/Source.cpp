/*

o Programmer name:	Yu Tian
o Course number:1748
o Date: 10/15
o Purpose: haircut
o Input:0,0,0,0,1,1,1,1,1,0
o Output:
Lemme Calculate Your Corsair Salon Service!
Who? (0=child/1=adult):0
Coloring? (0=no/1=yes):0
Highlights? (0=no/1=yes):0
Wave? (0=no/1=yes):0
Weekend Haircut?(0=no/1=yes) 1
You Spent $16.17 On Your Corsair Salon Service Including 8.25% Sales Tax



Lemme Calculate Your Corsair Salon Service!
Who? (0=child/1=adult):1
Coloring? (0=no/1=yes):1
Highlights? (0=no/1=yes):1
Wave? (0=no/1=yes):1
Weekend Haircut?(0=no/1=yes) 0
You Spent $70.35 On Your Corsair Salon Service Including 8.25% Sales Tax



Lemme Calculate Your Corsair Salon Service!
Who? (0=child/1=adult):
*/
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;
double childAdult(double cost){
	int who;
	cout << "Who? (0=child/1=adult):";
	cin >> who;
	switch (who) {
	case 0:
		cost += 12.99;
		return cost;
	case 1:
		cost += 19.99;
		return cost;
	default:
		return childAdult(cost);

	}
}
double color(double cost) {
	int Coloring;
	cout << "Coloring? (0=no/1=yes):";
	cin >> Coloring;
	switch (Coloring) {
	case 0:
		
		return cost;
	case 1:
		cost += 20.00;
		return cost;
	default:
		return color(cost);

	}
}
double Highlight(double cost) {
	int light;
	cout << "Highlights? (0=no/1=yes):";
	cin >> light;
	switch (light) {
	case 0:

		return cost;
	case 1:
		cost += 10.00;
		return cost;
	default:
		return Highlight(cost);

	}
}
double Wave(double cost) {
	int wave;
	cout << "Wave? (0=no/1=yes):";
	cin >> wave;
	switch (wave) {
	case 0:

		return cost;
	case 1:
		cost += 15.00;
		return cost;
	default:
		return Wave(cost);

	}
}
double Weekend_Surcharge(double cost) {
	int Weekend;
	cout << "Weekend Haircut?(0=no/1=yes):";
	cin >> Weekend;
	switch (Weekend) {
	case 0:

		return cost;
	case 1:
		cost *= 1.15;
		return cost;
	default:
		return Weekend_Surcharge(cost);

	}
}

int haircut() {
	const string start = "Lemme Calculate Your Corsair Salon Service!\n";
	cout << start;
	const double taxRate = 0.0825;
	
	double cost=0;
	cost = childAdult(cost);
	cost = color(cost);
	cost = Highlight(cost);
	cost = Wave(cost);
	cost = Weekend_Surcharge(cost);
	cost *= (1+taxRate);
	cout << "You Spent $" << setprecision(2) << fixed << cost << " On Your Corsair Salon Service Including 8.25% Sales Tax\n\n" << endl;
	return haircut();
}

int main() {

	haircut();





	return 0;

}