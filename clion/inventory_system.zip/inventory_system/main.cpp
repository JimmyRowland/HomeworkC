#include <string>
#include <iostream>
#include "inventory.h"

int main() {
    Inventory system;
    system.run_inventory();

    return 0;
}