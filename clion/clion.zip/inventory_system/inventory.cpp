#include <string>
#include <iostream>
#include "inventory.h"
using namespace std;
Inventory::Inventory() {

}

Inventory::~Inventory() {

}

void Inventory::welcome_message() const {
    cout << "what's up\n" << endl;
}

void Inventory::print_production_status_first_line() const {
    cout<<month<<widget_onhand<<widget_back_ordered<<endl;
}

char Inventory::prompt_good_or_bad() const {
    char good_or_bad;
    while(good_or_bad!='g' && good_or_bad!='b'){
        cout<<"bad"<<endl;

        cin >> good_or_bad;

    }
    return good_or_bad;

}

int Inventory::promt_number_sell() const {
    int sale_number;
    cout<<"no sale"<<endl;

    cin >> sale_number;
    return sale_number;
}

char Inventory::prompt_comtinue() const {

    char yes_or_no;
    while(yes_or_no!='y' &&'n'){
        cout << "no" <<endl;
        cin >> yes_or_no;
    }

    return yes_or_no;
}

void Inventory::update_private_variables(char good_bad, int sale_number) {
    month++;
    if(good_bad=='g') widget_onhand+=100; //do calculation here;
    else widget_onhand +=1;
    widget_onhand-= sale_number;
}
void Inventory::print_status_lastline() const {
    cout<<month-1<<widget_onhand<<widget_back_ordered<<endl;
}
void Inventory::run_inventory() {
    welcome_message();
    char whether_continue= 'y';
    char good_bad;
    int sale_number=0;
    while(whether_continue=='y'){
        print_production_status_first_line();
        good_bad=prompt_good_or_bad();
        sale_number=promt_number_sell();
        whether_continue=prompt_comtinue();
        update_private_variables(good_bad,sale_number);
    }
    print_status_lastline();
}


