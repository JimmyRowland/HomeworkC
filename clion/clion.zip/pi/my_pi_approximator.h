#ifndef PI_MY_PI_APPROXIMATOR_H
#define PI_MY_PI_APPROXIMATOR_H
double pi(int n);
#endif //PI_MY_PI_APPROXIMATOR_H
