
//////////////////////////////////////////////////////////////////////////////////////
//																					//
//	Jisu Han																		//
//	09/30/2017																		//
//	Purpose: Make a calculator that calculates the Month and date of easter by year	//
//	Input: 2000					                                                    //
//	Output:
//  What's the year: 2000
//  Easter Month is April
//  Easter Day is 23
//																					//
//////////////////////////////////////////////////////////////////////////////////////
//#include "easterCalculator.h"
//#include <iostream>
//using namespace std;
//int main(){
//
//    EasterCalculator easter1;
//    easter1.printEasterDay();
//    system("pause");
//    return 0;
//}